Name: Cameron Teed 
Student ID: 101227413
Install Instructions:
	-Type "npm install" in the directory the "server.js" file is located

Install/Launch Instructions:
	-Ensure the latest version of Node and NPM are installed
	-Go to correct directory, run "npm install"
	-Open up a comand window in the directory the "server.js" file is located
	-Type "node server.js" to run the code
	-Go to "http://localhost:3000/index.html"
	- Create and account or login with "admin" "admin"
	- Can also try logging in with "cameronteed" "test"
	- Can add shared todo list with this: 6573bbb00f1efefdf97da769
	- Create, add, and edit to do lists

Testing Instructions:
http://localhost:3000/index.html
http://localhost:3000/admin
http://localhost:3000/login
http://localhost:3000/signup

youtube part-1 link:
https://youtu.be/SvYMmhwVLvc
part2 - oops i left some stuff out
https://youtu.be/zQcLXj24YyA